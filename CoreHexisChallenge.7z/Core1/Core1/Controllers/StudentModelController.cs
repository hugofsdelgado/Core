﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Core1.Models;

namespace Core1.Controllers
{
    public class StudentModelController : Controller
    {
        private readonly StudentContext _context;

        public StudentModelController(StudentContext context)
        {
            _context = context;
        }

        // GET: StudentModel
        public IActionResult Index()
        {
            var _studentlst = _context.tStudent.
                            Join(_context.tSchool, e => e.School_ID, s => s.ID,
                            (e, s) => new StudentViewModel
                            {
                                ID = e.ID,
                                Name = e.Name,
                                School = s.Name,
                                Number = e.Number
                            }).ToList();
            IList<StudentViewModel> studentlst = _studentlst;
            return View(studentlst);

        }

        // GET: StudentModel/Details/5
        public IActionResult Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var studentViewModel = _context.tStudent.
                            Join(_context.tSchool, e => e.School_ID, s => s.ID,
                            (e, s) => new StudentViewModel
                            {
                                ID = e.ID,
                                Name = e.Name,
                                School = s.Name,
                                Number = e.Number
                            }).FirstOrDefault(m => m.ID == id);

            if (studentViewModel == null)
            {
                return NotFound();
            }

            return View(studentViewModel);
        }

        // GET: StudentModel/Create
        public IActionResult Create()
        {
            List<tSchool> schools = new List<tSchool>();
            schools = _context.tSchool.ToList();
            ViewBag.lstSchools = schools;
            return View();
        }

        // POST: StudentModel/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        public IActionResult Create([Bind("ID,Number,Name,School_ID")] tStudent student)
        {
            if (ModelState.IsValid)
            {
                _context.Add(student);
                _context.SaveChanges();
                return RedirectToAction(nameof(Index));
            }

            return View(student);
        }

        // GET: StudentModel/Edit/5
        public IActionResult Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var studentViewModel = _context.tStudent.Find(id);

            
            if (studentViewModel == null)
            {
                return NotFound();
            }

            List<tSchool> schools = new List<tSchool>();
            schools = _context.tSchool.ToList();
            ViewBag.lstSchools = schools;
            return View(studentViewModel);
        }

        // POST: StudentModel/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(int id, [Bind("ID,Number,Name,School_ID")] tStudent student)
        {
            if (id != student.ID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(student);
                    _context.SaveChanges();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!StudentViewModelExists(student.ID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(student);
        }

        // GET: StudentModel/Delete/5
        public IActionResult Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var studentViewModel = _context.tStudent.
                            Join(_context.tSchool, e => e.School_ID, s => s.ID,
                            (e, s) => new StudentViewModel
                            {
                                ID = e.ID,
                                Name = e.Name,
                                School = s.Name,
                                Number = e.Number,
                                School_ID = e.School_ID
                            }).FirstOrDefault(m => m.ID == id);
            if (studentViewModel == null)
            {
                return NotFound();
            }

            return View(studentViewModel);
        }

        // POST: StudentModel/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int id)
        {
            var student = _context.tStudent.Find(id);
            _context.tStudent.Remove(student);
            _context.SaveChanges();
            return RedirectToAction(nameof(Index));
        }

        private bool StudentViewModelExists(int id)
        {
            return _context.StudentViewModel.Any(e => e.ID == id);
        }
    }
}
