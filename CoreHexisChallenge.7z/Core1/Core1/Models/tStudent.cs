﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace Core1.Models
{
    public class tStudent
    {
        [Key]
        public int ID { get; set; }
        [Display(Name = "Student Number")]
        public int Number { get; set; }
        [Display(Name = "Student Name")]
        public string Name { get; set; }
        [Display(Name = "School")]
        public int School_ID { get; set; }
    }
}
