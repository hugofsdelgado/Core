﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Core1.Models;

namespace Core1.Models
{
    public class StudentContext : DbContext
    {
        public StudentContext(DbContextOptions<StudentContext> options) : base(options)
        {

        }
        public DbSet<tStudent> tStudent { get; set; }
        public DbSet<tSchool> tSchool { get; set; }
        public DbSet<Core1.Models.StudentViewModel> StudentViewModel { get; set; }
    }

    
}
