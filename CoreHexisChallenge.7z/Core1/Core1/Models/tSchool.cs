﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace Core1.Models
{
    public class tSchool
    {
        [Key]
        public int ID{ get; set; }

        [Display( Name = "School Name")]
        public string Name { get; set; }
    }
}
