﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace Core1.Models
{
    public class StudentViewModel
    {
        public int ID { get; set; }
        public int Number { get; set; }
        public string Name { get; set; }
        public int School_ID { get; set; }
        public string School { get; set; }
    }
}
